const express = require('express');
const router = express.Router();
var db = require('../lib/db');
var template = require('../lib/template.js');
var authCheck = require('../lib/authCheck.js');
var planTemplate = require('../lib/planTm.js');
var fs = require('fs');


// 메인 페이지
router.get('/', function (req, res) {
    if(authCheck.isOwner(req, res)){    // 로그인 상태
        db.query(`SELECT * FROM tour_plan WHERE userID = '${req.session.userID}'`,
        function(error, results, fields){
            if(error) throw error;
            if(results.length > 0){ // 일정이 있는 경우 일정 목록페이지
                res.redirect('/plan/list');
                return false;
            } else{ // 일정이 없는 경우 기본 화면
                var header = template.header(authCheck.statusUI(req, res), authCheck.statusUI_mp(req, res));
                var scheBox = planTemplate.scheBox();
                var popular = planTemplate.popular();
                var body = planTemplate.planMain(scheBox, popular);
                var css = `<link href="/css/default.css" rel="stylesheet">`;
                var html = template.HTML(css, header, body);
                res.send(html);
            }
        })
    } else{     // 로그인이 안 되어있으면 기본 화면
        var header = template.header(authCheck.statusUI(req, res), authCheck.statusUI_mp(req, res));
        var scheBox = planTemplate.scheBox();
        var popular = planTemplate.popular();
        var body = planTemplate.planMain(scheBox, popular);
        var css = `<link href="/css/default.css" rel="stylesheet">`;
        var html = template.HTML(css, header, body);
        res.send(html);
    }
    
})

const sidoCode = JSON.parse(fs.readFileSync('./data/areacode/sidoCode.json', 'utf-8'));
const gyeonggi = JSON.parse(fs.readFileSync('./data/areacode/json/gyeonggi.json', 'utf-8'));
const gangwon = JSON.parse(fs.readFileSync('./data/areacode/json/gangwon.json', 'utf-8'));
const chungbuk = JSON.parse(fs.readFileSync('./data/areacode/json/chungbuk.json', 'utf-8'));
const chungnam = JSON.parse(fs.readFileSync('./data/areacode/json/chungnam.json', 'utf-8'));
const gyeongbuk = JSON.parse(fs.readFileSync('./data/areacode/json/gyeongbuk.json', 'utf-8'));
const gyeongnam = JSON.parse(fs.readFileSync('./data/areacode/json/gyeongnam.json', 'utf-8'));
const jeonbuk = JSON.parse(fs.readFileSync('./data/areacode/json/jeonbuk.json', 'utf-8'));
const jeonnam = JSON.parse(fs.readFileSync('./data/areacode/json/jeonnam.json', 'utf-8'));

// 일정 생성
router.post('/create_process', function(req, res){
    if(!authCheck.isOwner(req, res)){    // 로그인이 안 되어있으면 로그인 페이지 이동
        return res.send(`<script type="text/javascript">alert("로그인이 필요한 서비스입니다."); 
            document.location.href="/auth/login";</script>`);  
    } 
    var post = req.body;
    var startDate = post.startDate;
    var endDate = post.endDate;
    var sido = post.sido;
    var sigun = post.sigun;
    var location = '',
        latitude = '',
        longitude = '';

    
    if(sido == 31){
        location = gyeonggi[sigun - 1].name;
        latitude = gyeonggi[sigun - 1].latitude;
        longitude = gyeonggi[sigun - 1].longitude;
    }
    else if(sido == 32){
        location = gangwon[sigun - 1].name;
        latitude = gangwon[sigun - 1].latitude;
        longitude = gangwon[sigun - 1].longitude;
    }
    else if(sido == 33){
        location = chungbuk[sigun - 1].name;
        latitude = chungbuk[sigun - 1].latitude;
        longitude = chungbuk[sigun - 1].longitude;
    }
    else if(sido == 34){
        location = chungnam[sigun - 1].name;
        latitude = chungnam[sigun - 1].latitude;
        longitude = chungnam[sigun - 1].longitude;
    }
    else if(sido == 35){
        location = gyeongbuk[sigun - 1].name;
        latitude = gyeongbuk[sigun - 1].latitude;
        longitude = gyeongbuk[sigun - 1].longitude;
    }
    else if(sido == 36){
        location = gyeongnam[sigun - 1].name;
        latitude = gyeongnam[sigun - 1].latitude;
        longitude = gyeongnam[sigun - 1].longitude;
    }
    else if(sido == 37){
        location = jeonbuk[sigun - 1].name;
        latitude = jeonbuk[sigun - 1].latitude;
        longitude = jeonbuk[sigun - 1].longitude;
    }
    else if(sido == 38){
        location = jeonnam[sigun - 1].name;
        latitude = jeonnam[sigun - 1].latitude;
        longitude = jeonnam[sigun - 1].longitude;
    }
    else if(sido == 39){    // 제주
        location = sidoCode[16].name;
        latitude = sidoCode[16].latitude;
        longitude = sidoCode[16].longitude;
    }
    else {  // 광역시
        location = sidoCode[sido - 1].name;
        latitude = sidoCode[sido - 1].latitude;
        longitude = sidoCode[sido - 1].longitude;
    }
    

    db.query('INSERT INTO tour_plan (startDate, endDate, locationCode, location, userID, latitude, longitude) VALUES(?,?,?,?,?,?,?)', 
    [startDate, endDate, sido, location, req.session.userID, latitude, longitude], function (error2, data) {
        if (error2) throw error2;
        res.redirect('/plan/list');
    });
})


// 일정 삭제
router.post('/delete_process/:planID', function(req, res){ 
    db.query(`DELETE FROM tour_plan WHERE planID = ${req.params.planID}`, 
        function(error, results){
            if(error) throw error;
            res.send(`<script type="text/javascript"> 
                document.location.href="/plan/list";</script>`);
        })
})

 // 여행 지역 수정
 router.post('/update/location/:planID', function(req, res){
    var post = req.body;
    var sido = post.sido;
    var sigun = post.sigun;
    var location = '',
        latitude = '',
        longitude = '';
    
    if(sido == 31){
        location = gyeonggi[sigun - 1].name;
        latitude = gyeonggi[sigun - 1].latitude;
        longitude = gyeonggi[sigun - 1].longitude;
    }
    else if(sido == 32){
        location = gangwon[sigun - 1].name;
        latitude = gangwon[sigun - 1].latitude;
        longitude = gangwon[sigun - 1].longitude;
    }
    else if(sido == 33){
        location = chungbuk[sigun - 1].name;
        latitude = chungbuk[sigun - 1].latitude;
        longitude = chungbuk[sigun - 1].longitude;
    }
    else if(sido == 34){
        location = chungnam[sigun - 1].name;
        latitude = chungnam[sigun - 1].latitude;
        longitude = chungnam[sigun - 1].longitude;
    }
    else if(sido == 35){
        location = gyeongbuk[sigun - 1].name;
        latitude = gyeongbuk[sigun - 1].latitude;
        longitude = gyeongbuk[sigun - 1].longitude;
    }
    else if(sido == 36){
        location = gyeongnam[sigun - 1].name;
        latitude = gyeongnam[sigun - 1].latitude;
        longitude = gyeongnam[sigun - 1].longitude;
    }
    else if(sido == 37){
        location = jeonbuk[sigun - 1].name;
        latitude = jeonbuk[sigun - 1].latitude;
        longitude = jeonbuk[sigun - 1].longitude;
    }
    else if(sido == 38){
        location = jeonnam[sigun - 1].name;
        latitude = jeonnam[sigun - 1].latitude;
        longitude = jeonnam[sigun - 1].longitude;
    }
    else if(sido == 39){    // 제주
        location = sidoCode[16].name;
        latitude = sidoCode[16].latitude;
        longitude = sidoCode[16].longitude;
    }
    else {  // 광역시
        location = sidoCode[sido - 1].name;
        latitude = sidoCode[sido - 1].latitude;
        longitude = sidoCode[sido - 1].longitude;
    }
    

    db.query(`UPDATE tour_plan SET locationCode=?, location=?, latitude=?, longitude=? WHERE planID = ${req.params.planID}`,
    [sido, location, latitude, longitude], function(error, results){
        if(error) throw error;
        res.redirect(`/plan/detail/${req.params.planID}`);
    })
})


// 여행 날짜 수정
router.post('/update/date/:planID', function(req, res){
    var post = req.body;
    var startDate = post.startDate;
    var endDate = post.endDate;

    db.query(`UPDATE tour_plan SET startDate=?, endDate=? WHERE planID = ${req.params.planID}`,
    [startDate, endDate], function(error, results){
        if(error) throw error;
        res.redirect(`/plan/detail/${req.params.planID}`);
    })
})

// 여행 제목 수정
router.post('/update/title/:planID', function(req, res){
    var post = req.body;
    var title = post.title;

    db.query(`UPDATE tour_plan SET title=? WHERE planID = ${req.params.planID}`,
    [title], function(error, results){
        if(error) throw error;
        res.redirect(`/plan/detail/${req.params.planID}`);
    })
})


function getToday(){
    var date = new Date();
    var year = date.getFullYear();
    var month = ("0" + (1 + date.getMonth())).slice(-2);
    var day = ("0" + date.getDate()).slice(-2);

    return year + "-" + month + "-" + day;
}

function getDt(dt){
    const temp = new Date(dt);
    const year = temp.getFullYear();
    const month = temp.getMonth() + 1;
    const date = temp.getDate();

    return `${year}-${month >= 10 ? month : '0' + month}-${date >= 10 ? date : '0' + date}`;
}

// 일정 목록
router.get('/list', function (req, res) {
    db.query(`SELECT planID, title, location, date_format(startDate, '%Y-%m-%d') AS startDate, date_format(endDate, '%Y-%m-%d') AS endDate FROM tour_plan 
    WHERE userID = '${req.session.userID}' ORDER BY startDate`, function(error, results){
        if(error) throw error;
        var header = template.header(authCheck.statusUI(req, res), authCheck.statusUI_mp(req, res));
        var scheBox = planTemplate.scheBox();
        var list = [];
        for(var i = 0; i < results.length; i++){
            var location = results[i].location;
            var startDate = results[i].startDate;
            var endDate = results[i].endDate;
            var days = (new Date(startDate).getTime() - new Date(getToday()).getTime()) / (24 * 60 * 60 * 1000);
            var travel_days = (new Date(endDate).getTime() - new Date(startDate).getTime()) / (24 * 60 * 60 * 1000);
            var d_day = `D - ${days}`;
            
            if(days <= 0 && days >= travel_days * -1){
                d_day = '오늘은 여행일입니다. 즐거운 여행 되세요!';
            } else if(days < travel_days * -1) {
                d_day = '지난 여행';
            }

            var planID = results[i].planID;
            var title = results[i].title;
            if(!title){
                title = `${location} 여행`;
            }   
            list[i] = planTemplate.list(title, startDate, endDate, d_day, planID);
        }
        var plist = list.join('');
        var body = planTemplate.planList(scheBox, plist, req.session.nickname);
        var css = `<link href="/css/planList.css" rel="stylesheet">`;
        var html = template.HTML(css, header, body);
        res.send(html);
    })
})

function create_bmList(results){
        var bookList = [];
        var list = [];
        for(var i = 0; i < results.length; i++){
            bookList.push({
                index: i,
                title: results[i].title,
                longitude: results[i].longitude,
                latitude: results[i].latitude,
                addr: results[i].addr
            });
            list[i] = template.bm_list(bookList[i].title, bookList[i].longitude, bookList[i].latitude, bookList[i].addr, i);
        }
        var bm_list = list.join('');
        return bm_list;
}

// 일정 상세 페이지
router.get('/detail/:planID', function (req, res) {
    var sql1 = `SELECT planID, title, location, date_format(startDate, '%Y-%m-%d') AS startDate, date_format(endDate, '%Y-%m-%d') AS endDate FROM tour_plan 
    WHERE planID = '${req.params.planID}'; `;
    var sql2 = `SELECT title, longitude, latitude, addr FROM bookmark WHERE planID = '${req.params.planID}'; `;
    var sql3 = `SELECT title, date, startTime, singleID FROM single_plan 
    WHERE planID = '${req.params.planID}' ORDER BY number; `;
    db.query(sql1 + sql2 + sql3, function(error, results){
        if(error) throw error;
        // sql1 result
        var location = results[0][0].location;
        var startDate = results[0][0].startDate;
        var endDate = results[0][0].endDate;
        var planID = results[0][0].planID;
        var title = results[0][0].title;
        
        // sql2 result
        var bm_list = create_bmList(results[1]);
       
        // sql3 result
        var s_info = [];
        for(var i = 0; i < results[2].length; i++){
           s_info.push({
            title: results[2][i].title,
            date: results[2][i].date
           })
        }

        if(!title){
            title = `${location} 여행`;
        }
        var days = (new Date(startDate).getTime() - new Date(getToday()).getTime()) / (24 * 60 * 60 * 1000);
        var travel_days = (new Date(endDate).getTime() - new Date(startDate).getTime()) / (24 * 60 * 60 * 1000);
        var d_day = `여행이 ${days}일 남았네요!`;
        if(days <= 0 && days >= travel_days * -1){
            d_day = '오늘은 여행일입니다. 즐거운 여행 되세요!';
        } else if(days < travel_days * -1) {
            d_day = '지난 여행입니다. 즐거운 여행 되셨나요?';
        }

        var s_list = [];
        for(var i = 0; i < results[2].length; i++)
            s_list[i] = planTemplate.s_list(results[2], i);
        
        // 배열 초기화
        var listByDate = [];
        for(var i = 0; i <= travel_days; i++)
            listByDate[i] = '';

        for(var i = 0; i < s_list.length; i++){
            for(var j = 1; j <= travel_days + 1; j++){
                if(s_list[i].includes(`List_${j}`)){
                    listByDate[j - 1] += s_list[i];
                }
            }
        }

        var scheTable = '';
        for(var j = 1; j <= travel_days + 1; j++){
            scheTable += planTemplate.create_box(j, listByDate[j - 1]);
        }    
       
        var header = template.header(authCheck.statusUI(req, res), authCheck.statusUI_mp(req, res));
        var body = planTemplate.planDetail(title, location, startDate, endDate, d_day, planID, scheTable, bm_list);
        var css = `<link href="/css/planDetail.css" rel="stylesheet">`;
        var html = template.HTML(css, header, body);
        res.send(html);
    })
})

// 북마크 추가
router.post('/add_bookmark/:planID', function(req, res){
    var post = req.body;
    var title = post.title;
    var longitude = post.longitude;
    var latitude = post.latitude;
    var addr = post.addr;
    //console.log(post);
 
    db.query('INSERT INTO bookmark (title, longitude, latitude, addr, userID, planID) VALUES(?,?,?,?,?,?)', 
    [title, longitude, latitude, addr, req.session.userID, req.params.planID], function (err, data) {
        if(err) throw err;
        console.log('success');
        res.send('bookmark');
    });
   
})
// 북마크 삭제
router.post('/delete_bookmark', function(req, res){ 
    var post = req.body;
    var longitude = post.longitude;
    var latitude = post.latitude;
    db.query(`DELETE FROM bookmark WHERE longitude = ${longitude} AND latitude = ${latitude}`, 
        function(error, results){
            if(error) throw error;
            console.log('success');
            res.redirect('/');
        })
})

// 일정에 장소 추가
router.post('/add_to_plan/:planID', function(req, res){
    var post = req.body;
    var title = post.title;
    var sche_dt = post.sche_dt;
    console.log(post);

    db.query(`INSERT INTO single_plan (title, date, planID, number) VALUES(?,?,?,?)`, [title, sche_dt, req.params.planID,0],
    function(err, results){
        if(err) throw err;
        console.log('success');
        res.send('addtoplan');
    })
})

// 스케줄 삭제
router.post('/delete_schedule', function(req, res){ 
    var post = req.body;
    var singleID = post.singleID;
    db.query(`DELETE FROM single_plan WHERE singleID = ?`, [singleID],
        function(error, results){
            if(error) throw error;
            console.log('success');
            res.redirect('/');
        })
})

// 일정에 시간 추가
router.post('/add_time', function(req, res){
    var post = req.body;
    var time = post.time;
    var singleId = post.singleID;
    db.query(`UPDATE single_plan SET startTime=? WHERE singleID = ?`,
    [time, singleId], function(error, results){
        if(error) throw error;
        console.log('success');
        res.send('success');
    })
})

// 일정 순서 변경
router.post('/update_order', function(req, res){
    var post = req.body;
    var singleID = post.singleID;
    
    singleID = JSON.parse(singleID);

    for(var i = 0; i < singleID.length; i++){
        db.query(`UPDATE single_plan
        SET date=?, number=? WHERE singleID=?`, 
        [singleID[i][0], i, singleID[i][1]],
        function(err, results){
            if(err) throw err;
            console.log('success');
            
        })
    }
    
    res.send('success');
})

module.exports = router;